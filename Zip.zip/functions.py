import pandas
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


#Function to make files with the data from ClickBus
def makeFiles(option, productsList):

    #Declaring the list to interact with the save procedure
    pathList = ["Relatórios-Stickers", "Relatórios-ClickBus"]
    SheetList = ["Adesivos", "Viagens"]
    
    #Saving procedure
    time = datetime.now()
    reportName = time.strftime("%d-%m-%Y_%H#%M#%S")
    df = pandas.DataFrame(productsList)
    df.transpose().to_csv("C:\\Users\\Henrique\\OneDrive\\Área de Trabalho\\HENRIQUENATOR\\RPA\\{}\\CSV_{}.csv".format(pathList[option], reportName), index=False, header=True)
    df.transpose().to_excel("C:\\Users\\Henrique\\OneDrive\\Área de Trabalho\\HENRIQUENATOR\\RPA\\{}\\Excel_{}.xlsx".format(pathList[option], reportName), sheet_name="{}".format(SheetList[option]))

    return reportName


#Function to send email with the Nerd Stickers report
def sendEmail(option, product, reportName):

    #Declaring the list to interact with the sending procedure
    pathList = ["Relatórios-Stickers", "Relatórios-ClickBus"]

    #Starting smtp server
    server = smtplib.SMTP("smtp.gmail.com", "587")
    server.ehlo()
    server.starttls()
    server.login("rickpincelli@gmail.com", "fqydnfdnizsvukdo")

    #Building the email
    body = "<b>Olá, tudo bem? Segue em anexo o relatório. O primeiro no formato 'XLSX' e o segundo no formato 'CSV'.</b>"
    emailOBJ = MIMEMultipart()
    emailOBJ["From"] = "rickpincelli@gmail.com"
    emailOBJ["To"] = "rickpincelli@gmail.com"
    emailOBJ["Subject"] = "Relatórios - {}".format(product)
    emailOBJ.attach(MIMEText(body, "html"))

    #Open XLSX file in read mode and binary
    XLSXFilePath = "C:\\Users\\Henrique\\OneDrive\\Área de Trabalho\\HENRIQUENATOR\\RPA\\{}\\Excel_{}.xlsx".format(pathList[option], reportName)
    XLSXAttchment = open(XLSXFilePath, "rb")
    #Read the file and convert to Base64
    att = MIMEBase("application", "octet-stream")
    att.set_payload(XLSXAttchment.read())
    encoders.encode_base64(att)
    #Adding a header and closing the XLSX file
    att.add_header("Content-Disposition", f"attachment; filename=Excel_{reportName}.xlsx")
    XLSXAttchment.close()
    emailOBJ.attach(att)

    #Open CSV file in read mode and binary
    CSVFilePath = "C:\\Users\\Henrique\\OneDrive\\Área de Trabalho\\HENRIQUENATOR\\RPA\\{}\\CSV_{}.csv".format(pathList[option], reportName)
    CSVAttchment = open(CSVFilePath, "rb")
    #Read the file and convert to Base64
    att = MIMEBase("application", "octet-stream")
    att.set_payload(CSVAttchment.read())
    encoders.encode_base64(att)
    #Adding a header and closing the CSV file
    att.add_header("Content-Disposition", f"attachment; filename=CSV_{reportName}.csv")
    CSVAttchment.close()
    emailOBJ.attach(att)

    #Sending the email
    server.sendmail(emailOBJ["From"], emailOBJ["To"], emailOBJ.as_string())
    server.quit()

    return